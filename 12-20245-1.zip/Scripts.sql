------------------------------------Create Tables------------------------------------
CREATE TABLE  "BILL_TRACK" 
   (    "CLIENTID" VARCHAR2(255), 
    "CRNT_DUE" NUMBER, 
    "LAST_PAID" DATE, 
     CONSTRAINT "BILL_TRACK_PK" PRIMARY KEY ("CLIENTID") ENABLE
   ) ;
   CREATE TABLE  "CLIENTDETAILS" 
   (    "CLIENTID" NUMBER, 
    "CLIENTNAME" VARCHAR2(50) NOT NULL ENABLE, 
    "CLIENTADDRESS" VARCHAR2(50) NOT NULL ENABLE, 
    "CONTACTNO" VARCHAR2(50) NOT NULL ENABLE, 
    "IP_ADDRESS" VARCHAR2(50) NOT NULL ENABLE, 
    "MAC_ADDRESS" VARCHAR2(50) NOT NULL ENABLE, 
    "CONNECTIONTYPE" VARCHAR2(50) NOT NULL ENABLE, 
    "CONNTAKENON" DATE NOT NULL ENABLE, 
    "PACKAGETAKEN" VARCHAR2(50) NOT NULL ENABLE, 
     CONSTRAINT "CLIENTDETAILS_PK" PRIMARY KEY ("CLIENTID") ENABLE
   ) ;
   CREATE TABLE  "COMPLAINDETAILS" 
   (    "COMPLAIN_ID" VARCHAR2(50), 
    "CLIENTID" VARCHAR2(50), 
    "PROBLEMDETAILS" VARCHAR2(50), 
    "PROBLEMSTATUS" VARCHAR2(50), 
    "PROBDATE" TIMESTAMP (6), 
     CONSTRAINT "COMPLAINDETAILS_PK" PRIMARY KEY ("COMPLAIN_ID") ENABLE
   ) ;
   CREATE TABLE  "COMPLAINLOG" 
   (    "COMPLAIN_ID" VARCHAR2(50), 
    "CLIENTID" VARCHAR2(50), 
    "RESOLVEDATE" TIMESTAMP (6), 
     CONSTRAINT "COMPLAINLOG_PK" PRIMARY KEY ("COMPLAIN_ID") ENABLE
   ) ;
   CREATE TABLE  "NEW_BILL_TABLE" 
   (    "BILLID" VARCHAR2(50), 
    "CLIENTID" VARCHAR2(50), 
    "PREVIOUS_DUE" NUMBER, 
    "CURRENT_BILL" NUMBER, 
    "CREATE_DATE" TIMESTAMP (6), 
    "RECIEVED_DATE" DATE, 
     CONSTRAINT "NEW_BILL_TABLE_CON" PRIMARY KEY ("BILLID") ENABLE
   ) ;
   CREATE TABLE  "PACKAGEDETAILS" 
   (    "PACKAGEID" VARCHAR2(50), 
    "PACKAGENAME" VARCHAR2(50), 
    "PACKAGEDETAILS" VARCHAR2(50), 
    "PRICE" NUMBER(10,0), 
     CONSTRAINT "PACKAGEDETAILS_PK" PRIMARY KEY ("PACKAGEID") ENABLE
   ) ;
--------------------------------------------------Functions-------------------------------------------
CREATE OR REPLACE FUNCTION  "PKG_COUNT" (var_clientid IN varchar)
return number IS
cnumber number;
BEGIN
select count(clientid) into cnumber from clientdetails where packagetaken = var_clientid GROUP BY packagetaken;
return cnumber;
END;
/
/
CREATE OR REPLACE FUNCTION  "FINDCLIENT" (var_clientid IN number)
return number
IS cnumber number;
cursor C1 is
select clientid from clientdetails where clientid=var_clientid;
begin
open c1;
fetch c1 into cnumber;
if c1%notfound then
cnumber :=0;
Else cnumber:=1;
end if;
return cnumber;
end;
/
/
CREATE OR REPLACE FUNCTION  "CLIENT_DURATION" (var_cid IN number)
return number is 
cnumber number;
Begin
select months_between(sysdate,conntakenon) into cnumber from clientdetails where clientid=var_cid;
return cnumber;
end;
/
--------------------------------------------------Procedures-------------------------------------------
/
CREATE OR REPLACE PROCEDURE  "INSERT_BILL" 
IS
var_date varchar2(50);
var_billid varchar2(50);
var_newbill number;
cursor c1 is select e.clientID,e.PACKAGETAKEN, d.CRNT_DUE, d.LAST_PAID from clientdetails e, bill_track d where e.clientid=d.clientid;
BEGIN
var_date:= concat('Bill_',to_char(sysdate,'MON_yy'));
for i in c1 LOOP
var_billid := concat(i.clientid,to_char(sysdate,'MON_yy'));

IF i.PACKAGETAKEN = 'PKG_01' THEN
var_newbill := i.CRNT_DUE + 500;
insert into new_bill_table(billid, clientid,previous_due,current_bill,Create_date) Values(concat(i.clientid,to_char(sysdate,'MON_yy')),i.clientid,i.CRNT_DUE,var_newbill,sysdate);
ELSIF i.PACKAGETAKEN = 'PKG_02' THEN
var_newbill := i.CRNT_DUE + 600;
insert into new_bill_table(billid, clientid,previous_due,current_bill,Create_date) Values(concat(i.clientid,to_char(sysdate,'MON_yy')),i.clientid,i.CRNT_DUE,var_newbill,sysdate);
ELSIF i.PACKAGETAKEN = 'PKG_03' THEN
var_newbill:=i.CRNT_DUE + 800;
insert into new_bill_table(billid, clientid,previous_due,current_bill,Create_date) Values(concat(i.clientid,to_char(sysdate,'MON_yy')),i.clientid,i.CRNT_DUE,var_newbill,sysdate);
ELSIF i.PACKAGETAKEN = 'PKG_04' THEN
var_newbill:=i.CRNT_DUE + 1000;
insert into new_bill_table(billid, clientid,previous_due,current_bill,Create_date) Values(concat(i.clientid,to_char(sysdate,'MON_yy')),i.clientid,i.CRNT_DUE,var_newbill,sysdate);
ELSIF i.PACKAGETAKEN = 'PKG_05' THEN
var_newbill:=i.CRNT_DUE + 1200;
insert into new_bill_table(billid, clientid,previous_due,current_bill,Create_date) Values(concat(i.clientid,to_char(sysdate,'MON_yy')),i.clientid,i.CRNT_DUE,var_newbill,sysdate);
ELSIF i.PACKAGETAKEN = 'PKG_06' THEN
var_newbill:=i.CRNT_DUE + 1500;
insert into new_bill_table(billid, clientid,previous_due,current_bill,Create_date) Values(concat(i.clientid,to_char(sysdate,'MON_yy')),i.clientid,i.CRNT_DUE,var_newbill,sysdate);
ELSIF i.PACKAGETAKEN = 'PKG_07' THEN
var_newbill := i.CRNT_DUE + 2000;
insert into new_bill_table(billid, clientid,previous_due,current_bill,Create_date) Values(concat(i.clientid,to_char(sysdate,'MON_yy')),i.clientid,i.CRNT_DUE,var_newbill,sysdate);
END IF;

END LOOP;
end;
/
/
CREATE OR REPLACE PROCEDURE  "CLIENT_COMPLAINS" (var_cid IN number)
is 
cursor c1 is select e.complain_id, e.problemdetails, e.problemstatus, e.probdate, f.resolvedate from complaindetails e, complainlog f where e.complain_id=f.complain_id and e.clientid=var_cid;
Begin
for i in c1 LOOP
dbms_output.put_line(i.complain_id || i.problemdetails || i.problemstatus || i.probdate || i.resolvedate);
END LOOP;
end;
/
/
CREATE OR REPLACE PROCEDURE  "CLIENT_BILLS" (var_clientid IN varchar)
IS
cursor c1 is select * from new_bill_table where clientid= var_clientid;
BEGIN
for i in c1 LOOP
dbms_output.put_line(i.billid || i.clientid || i.previous_due || i.CURRENT_BILL || i.create_date || i.recieved_date);
END LOOP;

END;
/
--------------------------------------------------Sequence-------------------------------------------
/
 CREATE SEQUENCE   "CLIENTDETAILSSEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 41 CACHE 20 NOORDER  NOCYCLE ;
 
 --------------------------------------------------Triggers-------------------------------------------
 CREATE OR REPLACE TRIGGER  "UPDATE_BILL" 
after update of RECIEVED_DATE on new_bill_table for each row
Begin
update BILL_TRACK SET CRNT_DUE=0, LAST_PAID=sysdate where clientid=:new.clientid;
END;
/

ALTER TRIGGER  "UPDATE_BILL" ENABLE;


CREATE OR REPLACE TRIGGER  "COMPLAINLOG_TRIGGER" 
after INSERT OR UPDATE on complaindetails for each row
Begin
if :new.problemstatus='Resolved' THEN
insert into complainlog(complain_id, clientid, resolvedate) values(:old.complain_id, :old.clientid,systimestamp);
END IF;
END;
/
ALTER TRIGGER  "COMPLAINLOG_TRIGGER" ENABLE;CREATE OR REPLACE TRIGGER  "CLIENTCHECK_TRIGGER" 
before insert on complaindetails for each row
declare
   ex_custom EXCEPTION;
   PRAGMA EXCEPTION_INIT( ex_custom, -20001 );
var_check number;
Begin
var_check:= findclient(:new.clientid);
if var_check=0 then
raise_application_error( -20001, 'Client Not found' );
end if;
END;
/


ALTER TRIGGER  "CLIENTCHECK_TRIGGER" ENABLE;CREATE OR REPLACE TRIGGER  "BI_CLIENTDETAILS" 
  before insert on "CLIENTDETAILS"               
  for each row  
begin   
  if :NEW."CLIENTID" is null then 
    select "CLIENTDETAILSSEQ".nextval into :NEW."CLIENTID" from dual; 
  end if; 
end; 

/
ALTER TRIGGER  "BI_CLIENTDETAILS" ENABLE;CREATE OR REPLACE FORCE VIEW  "RESOLVED_TICKET" ("COMPLAIN_ID", "CLIENTID", "PROBLEMDETAILS", "PROBLEMSTATUS", "PROBDATE", "RESOLVEDATE") AS 
  select e.complain_id, e.clientid, e.problemdetails, e.problemstatus, e.probdate, f.resolvedate from complaindetails e, complainlog f where e.complain_id=f.complain_id;CREATE OR REPLACE FORCE VIEW  "SHOWBILLSTATS" ("CLIENTID", "CLIENTNAME", "CONTACTNO", "PACKAGETAKEN", "CRNT_DUE", "LAST_PAID") AS 
  select e.clientID, e.clientname, e.contactno, e.PACKAGETAKEN, d.CRNT_DUE ,d.LAST_PAID from clientdetails e, bill_track d where e.clientid=d.clientid;CREATE OR REPLACE FORCE VIEW  "SHOWCLIENTS" ("CLIENTID", "CLIENTNAME", "CLIENTADDRESS", "CONTACTNO", "IP_ADDRESS", "MAC_ADDRESS", "CONNECTIONTYPE", "CONNTAKENON", "PACKAGETAKEN") AS 
  SELECT "CLIENTID","CLIENTNAME","CLIENTADDRESS","CONTACTNO","IP_ADDRESS","MAC_ADDRESS","CONNECTIONTYPE","CONNTAKENON","PACKAGETAKEN"
    
FROM ClientDetails;CREATE OR REPLACE FORCE VIEW  "UNPAID_THIS_MONTHS" ("CLIENTID", "CLIENTNAME", "CONTACTNO", "PACKAGETAKEN", "BILLID", "PREVIOUS_DUE", "CURRENT_BILL") AS 
  select e.clientid, e.clientname, e.contactno, e.packagetaken, f.billid, f.previous_due, f.CURRENT_BILL from clientdetails e, new_bill_table f where e.clientid=f.clientid AND to_char(CREATE_DATE,'Mon-YY') = to_char(sysdate,'Mon-YY') AND RECIEVED_DATE IS NULL;CREATE OR REPLACE FORCE VIEW  "UNRESOLVED_TICKET" ("COMPLAIN_ID", "CLIENTID", "CLIENTNAME", "CONTACTNO", "PACKAGETAKEN", "PROBLEMDETAILS", "PROBLEMSTATUS", "PROBDATE") AS 
  select e.complain_id, e.clientid, f.clientname, f.contactno, f.packagetaken, e.problemdetails, e.problemstatus,e.probdate from complaindetails e, clientdetails f where e.clientid=f.clientid AND e.problemstatus !='Resolved';CREATE OR REPLACE FORCE VIEW  "USERCOUNT" ("PACKAGENAME", "CLIENT_NUMBERS") AS 
  select  d.packagename ,COUNT(e.clientID) Client_Numbers from clientdetails e, packagedetails d where e.PACKAGETAKEN=d.packageid GROUP BY d.packagename ORDER BY COUNT(e.clientID) DESC;